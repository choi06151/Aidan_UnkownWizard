
MoCap Asset Pack by Awesome Dog
Release Date 29/11/2022

Thankyou for buying this motion asset pack! 

I hope you enjoy it and make good use of it. If you like it please leave a nice review for it on the marketplace :) If you have any technical issues or other problems with it though please do not hesitate to contact me and I'll do my best to help out. Email is contact@awesomedog.com or you can use the contact form on our website if you prefer.

Jim Clark
Awesome Dog Mocap


HELP WEBSITE

The help/support page for this asset pack is on our website.

This is the Link https://awesomedog.com/pages/unreal-mocap-pack-help


INCLUDED SOURCE FOLDERS

1. FBX Folder

This folder contains the animations as FBX files. You can use these to import into engines earlier than the officially supported 4.24 or if you wish to make modifications to the animations and re-import.

The project was built in 4.24 but will migrate to later versions. At this point in time migration has been tested in all versions since 4.24 up to the newly released UE5

2. UE Manny Pose Folder

This contains a T-Pose & A-Pose FBX of the UE mannequin. This is to help with retargeting in applications like motionbuilder and maya where you generally need to characterize the rig in a T-Pose.

